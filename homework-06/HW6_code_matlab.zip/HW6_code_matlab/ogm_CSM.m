classdef ogm_CSM < handle
    % Occupancy mapping using counting sensor model
    %
    %   Author: Chien Erh Lin, Maani Ghaffari Jadidi
    %   Date:   02/25/2021
    properties
        % map dimensions
        range_x = [-15, 20];
        range_y = [-25, 10];
        
        % sensor parameters
        z_max = 30;                 % max range in meters
        n_beams = 133;              % number of beams, we set it to 133 because not all measurements in the dataset contains 180 beams 
        
        % grid map paremeters
        grid_size = 0.135;
        w_obstacle = 2 * 0.135;     % width of obstacle, 2 * grid_size
        w_beam = 2 * pi/133;        % width of beam, 2 * pi/n_beams
        nn = 16;                    % number of nearest neighbor search
        
        % map structure
        map;                        % map!
        pose;                       % pose data
        scan;                       % laser scan data
        m_i = [];                   % cell i
        
        % -----------------------------------------------
        % To Do: 
        % prior initialization
        % Initialize prior, prior_alpha, and prior_beta
        % -----------------------------------------------
        prior = NaN;                % prior for setting up mean and variance
        prior_alpha = NaN;          % a small, uninformative prior for setting up alpha
        prior_beta = NaN;           % a small, uninformative prior for setting up beta
    end
    
    methods
        function obj = ogm_CSM(pose, scan)
            % class constructor
            % construct map points, i.e., grid centroids.
            x = obj.range_x(1):obj.grid_size:obj.range_x(2);
            y = obj.range_y(1):obj.grid_size:obj.range_y(2);
            [X,Y] = meshgrid(x,y);
            t = [X(:), Y(:)];
            
            % a simple KDtree data structure for map coordinates.
            obj.map.occMap = KDTreeSearcher(t);
            obj.map.size = size(t,1);
            
            % set robot pose and laser scan data
            obj.pose = pose;
            obj.pose.mdl = KDTreeSearcher([pose.x, pose.y]);
            obj.scan = scan;
            
            % -----------------------------------------------
            % To Do: 
            % Initialization map parameters such as map.mean, map.variance, map.alpha, and map.beta
            % -----------------------------------------------
            obj.map.mean = NaN;
            obj.map.variance = NaN;
            obj.map.alpha = NaN;
            obj.map.beta = NaN;
            
        end
        
        function build_ogm(obj)
            % build occupancy grid map using counting sensor model. We
            % first loop over all map cells, then for each cell, we find N
            % nearest neighbor poses to build the map. Note that this is
            % more efficient than looping over all poses and all map cells
            % for each pose which should be the case in online
            % (incremental) data processing.
            for i = 1:obj.map.size
                m = obj.map.occMap.X(i,:);
                idxs = knnsearch(obj.pose.mdl, m, 'K', obj.nn);
                if ~isempty(idxs)
                    for k = idxs
                        % pose k
                        pose_k = [obj.pose.x(k),obj.pose.y(k), obj.pose.h(k)];
                        if obj.is_in_perceptual_field(m, pose_k)
                            % laser scan at kth state; convert from
                            % cartesian to polar coordinates
                            [bearing, range] = cart2pol(obj.scan{k}(1,:), obj.scan{k}(2,:));
                            z = [range' bearing'];
                            
                            % -----------------------------------------------
                            % To Do: 
                            % update the sensor model in cell i
                            % -----------------------------------------------
                            
                        end
                    end
                end
                
                % -----------------------------------------------
                % To Do: 
                % update mean and variance for each cell i
                % -----------------------------------------------
                obj.map.mean(i) = NaN;
                obj.map.variance(i) = NaN;
            end
        end
        
        function inside = is_in_perceptual_field(obj, m, p)
            % check if the map cell m is within the perception field of the
            % robot located at pose p.
            inside = false;
            d = m - p(1:2);
            obj.m_i.range = sqrt(sum(d.^2));
            obj.m_i.phi = wrapToPi(atan2(d(2),d(1)) - p(3));
            % check if the range is within the feasible interval
            if (0 < obj.m_i.range) && (obj.m_i.range < obj.z_max)
                % here sensor covers -pi to pi!
                if (-pi < obj.m_i.phi) && (obj.m_i.phi < pi)
                    inside = true;
                end
            end
        end
        
        function counting_sensor_model(obj, z, i)
            % find the nearest beam
            bearing_diff = abs(wrapToPi(z(:,2) - obj.m_i.phi));
            [bearing_min, k] = min(bearing_diff);
            
            % -----------------------------------------------
            % To Do: 
            % implement the counting sensor model, update obj.map.alpha and
            % obj.map.beta
            % Hint: the way to determine occupied or free is similar to
            % inverse sensor model
            % -----------------------------------------------
        end
    end
end
